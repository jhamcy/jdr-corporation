document.addEventListener("DOMContentLoaded", function () {
    // 1. Text Statements Slideshow Loop
    const textSlides = document.querySelectorAll(".text-slide");
    let currentTextSlide = 0;
    const textInterval = 5000; // Rotates text every 5 seconds

    function changeTextSlide() {
        textSlides[currentTextSlide].classList.remove("active");
        currentTextSlide = (currentTextSlide + 1) % textSlides.length;
        textSlides[currentTextSlide].classList.add("active");
    }
    setInterval(changeTextSlide, textInterval);

    // 2. Service Images Gallery Slideshow Loop
    const imgSlides = document.querySelectorAll(".slide-wrap");
    const dots = document.querySelectorAll(".slide-dots span");
    let currentImgSlide = 0;
    const imgInterval = 4000; // Rotates images every 4 seconds

    function changeImageSlide() {
        if(imgSlides.length === 0) return;
        imgSlides[currentImgSlide].classList.remove("active");
        if(dots.length > 0) dots[currentImgSlide].classList.remove("active");
        
        currentImgSlide = (currentImgSlide + 1) % imgSlides.length;
        
        imgSlides[currentImgSlide].classList.add("active");
        if(dots.length > 0) dots[currentImgSlide].classList.add("active");
    }
    setInterval(changeImageSlide, imgInterval);
});
